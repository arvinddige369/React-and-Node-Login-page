import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate('');

    function handleSubmit(event) {
        event.preventDefault();
        axios.post('http://localhost:8081/login', { email, password })
            .then(res => {
                console.log(res.data); // Log the response for debugging
                if (res.data.status) {
                    alert(res.data.message); // Show success message
                    navigate('/Dashbordnew'); // Redirect to the Dashboard
                } else {
                    alert(res.data.message); // Show error message
                }
            })
            .catch(err => {
                console.error(err.response ? err.response.data : err.message); // Log error details
                alert('An error occurred. Please try again.');
            });
    }
    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label for="email">Email:</label>
                    <input type="text" name="email" required onChange={e => setEmail(e.target.value)} />
                </div>
                <div>
                    <label for="password">Password:</label>
                    <input type="password" name="password" required onChange={e => setPassword(e.target.value)} />
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    )
}
