import React from 'react'

export default function Dashbordnew() {
  return (
    <div>Dashbordnew</div>
  )
}
