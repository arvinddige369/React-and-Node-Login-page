import Dashbordnew from './componant/Dashbordnew';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './componant/Login';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/Dashbordnew" element={<Dashbordnew/>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
